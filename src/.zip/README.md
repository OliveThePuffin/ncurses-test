# Ascii art Craps

### Project Dependencies
`ncurses`
`cmake`

To setup and compile the project, run `./build.sh`

The executable `test` should appear in your directory
